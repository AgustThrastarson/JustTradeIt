namespace JustTradeIt.Software.API.Models.Dtos
{
    public class ItemDto
    {
        public int Id { get; set; }
        public string ImageUrl { get; set; }
    }
}