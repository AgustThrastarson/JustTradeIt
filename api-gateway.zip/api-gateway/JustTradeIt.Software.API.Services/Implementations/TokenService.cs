using JustTradeIt.Software.API.Models.Dtos;
using JustTradeIt.Software.API.Services.Interfaces;

namespace JustTradeIt.Software.API.Services.Implementations
{
    public class TokenService : ITokenService
    {
        public string GenerateJwtToken(UserDto user)
        {
            throw new System.NotImplementedException();
        }
    }
}