using JustTradeIt.Software.API.Services.Interfaces;

namespace JustTradeIt.Software.API.Services.Implementations
{
    public class JwtTokenService : IJwtTokenService
    {
        public bool IsTokenBlacklisted(int tokenId)
        {
            throw new System.NotImplementedException();
        }
    }
}