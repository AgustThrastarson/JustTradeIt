namespace JustTradeIt.Software.API.Repositories.Entities
{
    public class TradeItem
    {
        public int TradeId { get; set; }
        public int UserId { get; set; }
        public int ItemId { get; set; }
        
        //Nav Prop
        public Trade Trade { get; set; }
        public User User { get; set; }
        public Item Item { get; set; }
        
    }
}