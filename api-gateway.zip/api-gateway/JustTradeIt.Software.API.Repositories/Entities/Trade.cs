using System;
using System.Collections.Generic;

namespace JustTradeIt.Software.API.Repositories.Entities
{
    public class Trade
    {
        public int Id { get; set; }
        public string PublicIdentifier { get; set; }
        public DateTime IssuerDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string TradeStatus { get; set; }
        public string SenderId { get; set; }
        public string ReceiverId { get; set; }

        
        //Nav Prop
        public ICollection<TradeItem> TradeItems { get; set; }
        public virtual User Sender { get; set; }
        public virtual User Receiver { get; set; }
        

    }
}